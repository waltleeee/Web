function sk_timedCount()
{
    postMessage(1);
    setTimeout("sk_timedCount()", 1000 / 60);
}

sk_timedCount();