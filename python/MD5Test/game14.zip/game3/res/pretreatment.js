var g_urlParams = {};

var url = window.location.href;
var tmp = url.split("?");
if(tmp.length > 1)
{
    tmp = tmp[1].split("&");
    for(var i = 0; i < tmp.length; ++i)
    {
        var param = tmp[i].split("=");
        g_urlParams[param[0]] = param[1];
    }
}

var g_verSuffix = "";
if(g_urlParams["ver"] != null)
    g_verSuffix = "?ver=" + g_urlParams["ver"];